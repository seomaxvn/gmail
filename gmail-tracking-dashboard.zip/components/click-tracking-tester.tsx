"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MousePointer, ExternalLink, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function ClickTrackingTester() {
  const { toast } = useToast()
  const [trackingId, setTrackingId] = useState("wwwqh0w8dxrmb9170nj") // Pre-fill với ID test của bạn
  const [targetUrl, setTargetUrl] = useState("https://example.com")
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  // Tạo tracking ID mới
  const generateTrackingId = () => {
    const newId = Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
    setTrackingId(newId)
  }

  // Tạo click tracking URL
  const createClickUrl = () => {
    if (!trackingId || !targetUrl) return ""
    const baseUrl = "https://v0-new-project-ranh0lwla77.vercel.app"
    return `${baseUrl}/api/track/click/${trackingId}?url=${encodeURIComponent(targetUrl)}`
  }

  // Test click tracking
  const testClickTracking = () => {
    const clickUrl = createClickUrl()
    if (!clickUrl) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng nhập đầy đủ Tracking ID và Target URL",
        variant: "destructive",
      })
      return
    }

    console.log("🔗 Testing click tracking:", clickUrl)
    window.open(clickUrl, "_blank")

    // Refresh stats sau 2 giây
    setTimeout(() => {
      refreshStats()
    }, 2000)
  }

  // Refresh tracking stats
  const refreshStats = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/tracking/stats")
      const data = await response.json()
      setStats(data)
      console.log("📊 Updated stats:", data)
    } catch (error) {
      console.error("Error refreshing stats:", error)
    } finally {
      setLoading(false)
    }
  }

  // Tạo sample tracking data
  const createSampleData = async () => {
    try {
      const response = await fetch("/api/tracking/sample", { method: "POST" })
      const result = await response.json()

      if (result.success) {
        toast({
          title: "Thành công",
          description: "Đã tạo sample tracking data",
        })
        refreshStats()
      }
    } catch (error) {
      console.error("Error creating sample data:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tạo sample data",
        variant: "destructive",
      })
    }
  }

  const clickUrl = createClickUrl()

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MousePointer className="h-5 w-5" />
            <span>Click Tracking Tester</span>
          </CardTitle>
          <CardDescription>Test và debug click tracking functionality</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="trackingId">Tracking ID</Label>
              <div className="flex space-x-2">
                <Input
                  id="trackingId"
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  placeholder="Nhập tracking ID"
                />
                <Button variant="outline" onClick={generateTrackingId}>
                  Tạo Mới
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetUrl">Target URL</Label>
              <Input
                id="targetUrl"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                placeholder="https://example.com"
              />
            </div>
          </div>

          {clickUrl && (
            <div className="space-y-2">
              <Label>Generated Click Tracking URL:</Label>
              <div className="p-3 bg-muted rounded-md">
                <code className="text-sm break-all">{clickUrl}</code>
              </div>
            </div>
          )}

          <div className="flex space-x-2">
            <Button onClick={testClickTracking} disabled={!trackingId || !targetUrl}>
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Click Tracking
            </Button>
            <Button variant="outline" onClick={refreshStats} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Refresh Stats
            </Button>
            <Button variant="outline" onClick={createSampleData}>
              Tạo Sample Data
            </Button>
          </div>
        </CardContent>
      </Card>

      {stats && (
        <Card>
          <CardHeader>
            <CardTitle>Current Tracking Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.totalEmails}</div>
                <div className="text-sm text-muted-foreground">Total Emails</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.openedEmails}</div>
                <div className="text-sm text-muted-foreground">Opened</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{stats.totalOpens}</div>
                <div className="text-sm text-muted-foreground">Total Opens</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.totalClicks}</div>
                <div className="text-sm text-muted-foreground">Total Clicks</div>
              </div>
            </div>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="text-center">
                <div className="text-lg font-semibold">{stats.openRate.toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Open Rate</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold">{stats.clickRate.toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Click Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Alert>
        <AlertDescription>
          <strong>Cách test:</strong>
          <ol className="list-decimal list-inside mt-2 space-y-1">
            <li>Nhập Tracking ID và Target URL</li>
            <li>Nhấn "Test Click Tracking" - sẽ mở tab mới</li>
            <li>Tab mới sẽ redirect về Target URL</li>
            <li>Nhấn "Refresh Stats" để xem click được ghi nhận</li>
            <li>Kiểm tra Console logs để debug</li>
          </ol>
        </AlertDescription>
      </Alert>
    </div>
  )
}
