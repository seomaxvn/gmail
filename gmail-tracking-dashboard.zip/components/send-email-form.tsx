"use client"

import type React from "react"
import { useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Send, Copy, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface SendResult {
  messageId: string
  threadId: string
  trackingId: string | null
}

export function SendEmailForm() {
  const { data: session } = useSession()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [to, setTo] = useState("")
  const [subject, setSubject] = useState("")
  const [body, setBody] = useState("")
  const [enableTracking, setEnableTracking] = useState(true)
  const [sendResult, setSendResult] = useState<SendResult | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!to || !subject || !body) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng điền đầy đủ thông tin email",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/gmail/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          to,
          subject,
          body,
          tracking: enableTracking,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        setSendResult(result)

        toast({
          title: "Gửi email thành công",
          description: enableTracking ? "Email đã được gửi với tracking pixel" : "Email đã được gửi",
        })

        // Reset form
        setTo("")
        setSubject("")
        setBody("")
      } else {
        const error = await response.json()
        throw new Error(error.error || "Có lỗi xảy ra")
      }
    } catch (error: any) {
      toast({
        title: "Lỗi gửi email",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const copyTrackingId = () => {
    if (sendResult?.trackingId) {
      navigator.clipboard.writeText(sendResult.trackingId)
      toast({
        title: "Đã copy",
        description: "Tracking ID đã được copy vào clipboard",
      })
    }
  }

  if (!session) {
    return null
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Gửi Email với Tracking</CardTitle>
          <CardDescription>Gửi email và theo dõi khi người nhận mở email</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="to">Người nhận</Label>
              <Input
                id="to"
                type="email"
                placeholder="email@example.com"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subject">Tiêu đề</Label>
              <Input
                id="subject"
                placeholder="Tiêu đề email"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="body">Nội dung</Label>
              <Textarea
                id="body"
                placeholder="Nhập nội dung email... (hỗ trợ HTML)"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="min-h-[120px]"
                required
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="tracking" checked={enableTracking} onCheckedChange={setEnableTracking} />
              <Label htmlFor="tracking">Bật tracking khi người nhận mở email</Label>
            </div>

            {enableTracking && (
              <Alert>
                <AlertDescription>
                  <strong>Tracking hoạt động như thế nào:</strong>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                    <li>Một pixel ẩn (1x1px) sẽ được thêm vào email</li>
                    <li>Khi người nhận mở email, pixel sẽ được tải từ server</li>
                    <li>Các link trong email sẽ được chuyển qua tracking URL</li>
                    <li>Bạn sẽ nhận được thông báo real-time khi email được mở</li>
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Đang gửi...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Gửi Email
                </>
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>

      {/* Hiển thị kết quả gửi email */}
      {sendResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>Email đã được gửi thành công</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-sm font-medium">Message ID:</Label>
              <p className="text-sm text-muted-foreground font-mono">{sendResult.messageId}</p>
            </div>

            {sendResult.trackingId && (
              <div>
                <Label className="text-sm font-medium">Tracking ID:</Label>
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-muted-foreground font-mono">{sendResult.trackingId}</p>
                  <Button variant="outline" size="sm" onClick={copyTrackingId}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <Alert>
              <AlertDescription>
                Bạn có thể theo dõi trạng thái email này trong tab "Tracking Stats" để xem khi nào người nhận mở email.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
