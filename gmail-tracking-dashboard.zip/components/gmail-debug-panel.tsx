"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertTriangle, RefreshCw } from "lucide-react"

interface DebugInfo {
  hasSession: boolean
  hasAccessToken: boolean
  gmailApiStatus: "success" | "error" | "loading"
  lastError?: string
  profileInfo?: any
  apiResponses: {
    stats: "success" | "error" | "loading"
    recent: "success" | "error" | "loading"
  }
}

export function GmailDebugPanel() {
  const { data: session } = useSession()
  const [debugInfo, setDebugInfo] = useState<DebugInfo>({
    hasSession: false,
    hasAccessToken: false,
    gmailApiStatus: "loading",
    apiResponses: {
      stats: "loading",
      recent: "loading",
    },
  })

  useEffect(() => {
    if (session) {
      runDiagnostics()
    }
  }, [session])

  const runDiagnostics = async () => {
    const info: DebugInfo = {
      hasSession: !!session,
      hasAccessToken: !!session?.accessToken,
      gmailApiStatus: "loading",
      apiResponses: {
        stats: "loading",
        recent: "loading",
      },
    }

    setDebugInfo(info)

    if (!session?.accessToken) {
      setDebugInfo((prev) => ({
        ...prev,
        gmailApiStatus: "error",
        lastError: "Không có access token",
      }))
      return
    }

    try {
      // Test Gmail profile
      const profileRes = await fetch("/api/gmail/profile")
      if (profileRes.ok) {
        const profile = await profileRes.json()
        info.profileInfo = profile
        info.gmailApiStatus = "success"
      } else {
        info.gmailApiStatus = "error"
        info.lastError = `Profile API error: ${profileRes.status}`
      }

      // Test stats API
      const statsRes = await fetch("/api/gmail/stats")
      info.apiResponses.stats = statsRes.ok ? "success" : "error"

      // Test recent emails API
      const recentRes = await fetch("/api/gmail/recent")
      info.apiResponses.recent = recentRes.ok ? "success" : "error"

      setDebugInfo(info)
    } catch (error: any) {
      setDebugInfo((prev) => ({
        ...prev,
        gmailApiStatus: "error",
        lastError: error.message,
        apiResponses: {
          stats: "error",
          recent: "error",
        },
      }))
    }
  }

  const getStatusIcon = (status: "success" | "error" | "loading") => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "loading":
        return <RefreshCw className="h-4 w-4 animate-spin text-blue-500" />
    }
  }

  const getStatusBadge = (status: "success" | "error" | "loading") => {
    switch (status) {
      case "success":
        return (
          <Badge variant="default" className="bg-green-500">
            Hoạt động
          </Badge>
        )
      case "error":
        return <Badge variant="destructive">Lỗi</Badge>
      case "loading":
        return <Badge variant="secondary">Đang kiểm tra...</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Gmail Connection Debug</CardTitle>
            <CardDescription>Kiểm tra trạng thái kết nối với Gmail API</CardDescription>
          </div>
          <Button variant="outline" size="icon" onClick={runDiagnostics}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Session Status:</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(debugInfo.hasSession ? "success" : "error")}
                {getStatusBadge(debugInfo.hasSession ? "success" : "error")}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Access Token:</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(debugInfo.hasAccessToken ? "success" : "error")}
                {getStatusBadge(debugInfo.hasAccessToken ? "success" : "error")}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Gmail API:</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(debugInfo.gmailApiStatus)}
                {getStatusBadge(debugInfo.gmailApiStatus)}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Stats API:</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(debugInfo.apiResponses.stats)}
                {getStatusBadge(debugInfo.apiResponses.stats)}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Recent Emails API:</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(debugInfo.apiResponses.recent)}
                {getStatusBadge(debugInfo.apiResponses.recent)}
              </div>
            </div>
          </div>
        </div>

        {debugInfo.profileInfo && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Gmail Profile:</strong> {debugInfo.profileInfo.emailAddress}
              <br />
              <strong>Total Messages:</strong> {debugInfo.profileInfo.messagesTotal?.toLocaleString() || "N/A"}
              <br />
              <strong>Total Threads:</strong> {debugInfo.profileInfo.threadsTotal?.toLocaleString() || "N/A"}
            </AlertDescription>
          </Alert>
        )}

        {debugInfo.lastError && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Lỗi:</strong> {debugInfo.lastError}
            </AlertDescription>
          </Alert>
        )}

        {session?.user?.email && (
          <Alert>
            <AlertDescription>
              <strong>Đăng nhập với:</strong> {session.user.email}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  )
}
