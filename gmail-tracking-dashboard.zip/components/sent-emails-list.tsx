"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, RefreshCw, Paperclip } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SentEmail {
  id: string
  threadId: string
  recipient: string
  subject: string
  date: string
  snippet: string
  hasAttachment: boolean
  size: number
}

export function SentEmailsList() {
  const { data: session } = useSession()
  const [emails, setEmails] = useState<SentEmail[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (session?.accessToken) {
      fetchEmails()
    }
  }, [session])

  const fetchEmails = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/gmail/sent?limit=10")
      if (response.ok) {
        const data = await response.json()
        setEmails(data)
      }
    } catch (error) {
      console.error("Error fetching sent emails:", error)
    } finally {
      setLoading(false)
    }
  }

  const extractRecipientName = (recipient: string) => {
    const match = recipient.match(/^([^<]+)/)
    return match ? match[1].trim() : recipient
  }

  if (!session) {
    return null
  }

  return (
    <Card className="col-span-3">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Email Đã Gửi</CardTitle>
            <CardDescription>Danh sách email gần đây bạn đã gửi</CardDescription>
          </div>
          <Button variant="outline" size="icon" onClick={fetchEmails} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin mr-2" />
            <span>Đang tải email...</span>
          </div>
        ) : emails.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">Không có email nào được tìm thấy</div>
        ) : (
          <div className="space-y-4">
            {emails.map((email) => (
              <div
                key={email.id}
                className="flex items-start space-x-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <Avatar className="h-9 w-9">
                  <AvatarFallback>{extractRecipientName(email.recipient).charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium leading-none truncate">
                      Đến: {extractRecipientName(email.recipient)}
                    </p>
                    <div className="flex items-center space-x-2">
                      {email.hasAttachment && <Paperclip className="h-4 w-4 text-muted-foreground" />}
                      <Badge variant="outline" className="text-xs">
                        {email.size} KB
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm font-medium truncate">{email.subject || "(Không có tiêu đề)"}</p>
                  <p className="text-xs text-muted-foreground truncate">{email.snippet}</p>
                  <p className="text-xs text-muted-foreground">{email.date}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
