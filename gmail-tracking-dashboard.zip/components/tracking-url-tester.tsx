"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Copy, ExternalLink, Eye, MousePointer } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function TrackingUrlTester() {
  const { toast } = useToast()
  const [trackingId, setTrackingId] = useState("")
  const [testUrl, setTestUrl] = useState("https://example.com")

  // Lấy base URL hiện tại
  const getBaseUrl = () => {
    if (typeof window !== "undefined") {
      return window.location.origin
    }
    return "https://v0-new-project-ranh0lwla77.vercel.app"
  }

  const baseUrl = getBaseUrl()

  // Tạo tracking ID mẫu
  const generateSampleTrackingId = () => {
    const sampleId = Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
    setTrackingId(sampleId)
  }

  // Copy URL vào clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Đã copy",
      description: "URL đã được copy vào clipboard",
    })
  }

  // Test tracking pixel
  const testTrackingPixel = () => {
    if (!trackingId) {
      toast({
        title: "Thiếu Tracking ID",
        description: "Vui lòng nhập hoặc tạo Tracking ID",
        variant: "destructive",
      })
      return
    }

    const pixelUrl = `${baseUrl}/api/track/${trackingId}`
    window.open(pixelUrl, "_blank")
  }

  // Test click tracking
  const testClickTracking = () => {
    if (!trackingId || !testUrl) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng nhập đầy đủ Tracking ID và URL test",
        variant: "destructive",
      })
      return
    }

    const clickUrl = `${baseUrl}/api/track/click/${trackingId}?url=${encodeURIComponent(testUrl)}`
    window.open(clickUrl, "_blank")
  }

  const pixelUrl = trackingId ? `${baseUrl}/api/track/${trackingId}` : ""
  const clickUrl =
    trackingId && testUrl ? `${baseUrl}/api/track/click/${trackingId}?url=${encodeURIComponent(testUrl)}` : ""

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tracking URL Configuration</CardTitle>
          <CardDescription>Cấu hình và test các URL tracking cho email</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertDescription>
              <strong>Base URL hiện tại:</strong> <code className="bg-muted px-2 py-1 rounded">{baseUrl}</code>
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <Label htmlFor="trackingId">Tracking ID</Label>
            <div className="flex space-x-2">
              <Input
                id="trackingId"
                placeholder="Nhập tracking ID hoặc tạo mẫu"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
              />
              <Button variant="outline" onClick={generateSampleTrackingId}>
                Tạo Mẫu
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="testUrl">URL Test (cho click tracking)</Label>
            <Input
              id="testUrl"
              placeholder="https://example.com"
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>Tracking Pixel URL</span>
            </CardTitle>
            <CardDescription>URL để tracking khi email được mở</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {pixelUrl && (
              <div className="space-y-2">
                <Label>Generated URL:</Label>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 bg-muted p-2 rounded text-sm break-all">{pixelUrl}</code>
                  <Button variant="outline" size="sm" onClick={() => copyToClipboard(pixelUrl)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>HTML Pixel Code:</Label>
              <code className="block bg-muted p-2 rounded text-sm">
                {`<img src="${pixelUrl || "{TRACKING_URL}"}" width="1" height="1" style="display:none;" alt="" />`}
              </code>
            </div>

            <Button onClick={testTrackingPixel} disabled={!trackingId} className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Tracking Pixel
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MousePointer className="h-5 w-5" />
              <span>Click Tracking URL</span>
            </CardTitle>
            <CardDescription>URL để tracking khi link được click</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {clickUrl && (
              <div className="space-y-2">
                <Label>Generated URL:</Label>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 bg-muted p-2 rounded text-sm break-all">{clickUrl}</code>
                  <Button variant="outline" size="sm" onClick={() => copyToClipboard(clickUrl)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>HTML Link Code:</Label>
              <code className="block bg-muted p-2 rounded text-sm">
                {`<a href="${clickUrl || "{CLICK_TRACKING_URL}"}">Click here</a>`}
              </code>
            </div>

            <Button onClick={testClickTracking} disabled={!trackingId || !testUrl} className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Click Tracking
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Cách Hoạt Động</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">1. Tracking Pixel:</h4>
              <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Khi email được mở, trình duyệt tự động tải hình ảnh từ URL tracking</li>
                <li>Server ghi nhận thời gian, IP address, và user agent</li>
                <li>Pixel có kích thước 1x1px và trong suốt (không nhìn thấy)</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium mb-2">2. Click Tracking:</h4>
              <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Links trong email được thay thế bằng tracking URLs</li>
                <li>Khi click, server ghi nhận sự kiện rồi redirect về URL gốc</li>
                <li>Cho phép theo dõi tương tác chi tiết với nội dung email</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium mb-2">3. Domain Configuration:</h4>
              <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>
                  <strong>Development:</strong> <code>http://localhost:3000</code>
                </li>
                <li>
                  <strong>Production:</strong> <code>{baseUrl}</code>
                </li>
                <li>
                  <strong>Environment Variable:</strong> <code>NEXTAUTH_URL</code>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
