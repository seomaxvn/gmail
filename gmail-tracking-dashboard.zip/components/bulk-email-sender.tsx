"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Upload, Download, Send, Eye, Users, CheckCircle, XCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface EmailRecipient {
  email: string
  name?: string
  company?: string
  [key: string]: string | undefined
}

interface BulkSendResult {
  email: string
  status: "success" | "error"
  message: string
  trackingId?: string
}

export function BulkEmailSender() {
  const [recipients, setRecipients] = useState<EmailRecipient[]>([])
  const [subject, setSubject] = useState("")
  const [template, setTemplate] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [isSending, setSending] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<BulkSendResult[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [previewIndex, setPreviewIndex] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  // Sample template tiếng Việt
  const sampleTemplate = `Chào {{name}},

Chúng tôi rất vui mừng được giới thiệu sản phẩm mới đến {{company}}.

Đây là một cơ hội tuyệt vời để {{company}} có thể tối ưu hóa quy trình làm việc.

Để biết thêm chi tiết, vui lòng truy cập: &lt;a href="https://example.com"&gt;Tìm hiểu thêm&lt;/a&gt;

Trân trọng,
Đội ngũ Marketing`

  // Parse CSV file
  const parseCSV = (text: string): EmailRecipient[] => {
    const lines = text.trim().split("\n")
    if (lines.length < 2) return []

    const headers = lines[0].split(",").map((h) => h.trim().replace(/"/g, ""))
    const recipients: EmailRecipient[] = []

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim().replace(/"/g, ""))
      const recipient: EmailRecipient = { email: "" }

      headers.forEach((header, index) => {
        if (values[index]) {
          recipient[header.toLowerCase()] = values[index]
        }
      })

      if (recipient.email && recipient.email.includes("@")) {
        recipients.push(recipient)
      }
    }

    return recipients
  }

  // Handle file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    try {
      const text = await file.text()
      const parsedRecipients = parseCSV(text)

      if (parsedRecipients.length === 0) {
        toast({
          title: "Lỗi",
          description: "Không tìm thấy email hợp lệ trong file CSV",
          variant: "destructive",
        })
        return
      }

      setRecipients(parsedRecipients)
      toast({
        title: "Thành công",
        description: `Đã tải ${parsedRecipients.length} email từ file CSV`,
      })
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể đọc file CSV",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  // Add manual email
  const addManualEmail = () => {
    const emailInput = document.getElementById("manual-email") as HTMLInputElement
    const nameInput = document.getElementById("manual-name") as HTMLInputElement
    const companyInput = document.getElementById("manual-company") as HTMLInputElement

    const email = emailInput?.value.trim()
    const name = nameInput?.value.trim()
    const company = companyInput?.value.trim()

    if (!email || !email.includes("@")) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập email hợp lệ",
        variant: "destructive",
      })
      return
    }

    const newRecipient: EmailRecipient = { email, name, company }
    setRecipients([...recipients, newRecipient])

    // Clear inputs
    if (emailInput) emailInput.value = ""
    if (nameInput) nameInput.value = ""
    if (companyInput) companyInput.value = ""

    toast({
      title: "Thành công",
      description: "Đã thêm email vào danh sách",
    })
  }

  // Replace template placeholders
  const replaceTemplate = (template: string, recipient: EmailRecipient): string => {
    let result = template
    Object.keys(recipient).forEach((key) => {
      const value = recipient[key] || ""
      result = result.replace(new RegExp(`{{${key}}}`, "g"), value)
    })
    return result
  }

  // Preview email
  const getPreviewEmail = () => {
    if (recipients.length === 0) return template
    return replaceTemplate(template, recipients[previewIndex])
  }

  // Send bulk emails
  const sendBulkEmails = async () => {
    if (recipients.length === 0) {
      toast({
        title: "Lỗi",
        description: "Vui lòng thêm ít nhất một email",
        variant: "destructive",
      })
      return
    }

    if (!subject.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập tiêu đề email",
        variant: "destructive",
      })
      return
    }

    if (!template.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập nội dung email",
        variant: "destructive",
      })
      return
    }

    setSending(true)
    setProgress(0)
    setResults([])

    try {
      const response = await fetch("/api/gmail/bulk-send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify({
          recipients,
          subject,
          template,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to send bulk emails")
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder("utf-8")

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          const lines = chunk.split("\n").filter((line) => line.trim())

          for (const line of lines) {
            try {
              const data = JSON.parse(line)
              if (data.type === "progress") {
                setProgress(data.progress)
              } else if (data.type === "result") {
                setResults((prev) => [...prev, data.result])
              }
            } catch (e) {
              // Ignore invalid JSON
            }
          }
        }
      }

      toast({
        title: "Hoàn thành",
        description: "Đã gửi xong email hàng loạt",
      })
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Có lỗi xảy ra khi gửi email",
        variant: "destructive",
      })
    } finally {
      setSending(false)
    }
  }

  // Download sample CSV
  const downloadSampleCSV = () => {
    const csvContent = `email,name,company
john@example.com,John Doe,ABC Company
jane@example.com,Jane Smith,XYZ Corp
nguyen@example.com,Nguyễn Văn A,Công ty TNHH ABC`

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = "sample-emails.csv"
    link.click()
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Gửi Email Hàng Loạt
          </CardTitle>
          <CardDescription>Gửi email đến nhiều người nhận cùng lúc với template tùy chỉnh</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Upload CSV */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">1. Thêm danh sách email</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Upload file CSV</Label>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="flex-1"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {isUploading ? "Đang tải..." : "Chọn file CSV"}
                  </Button>
                  <Button variant="outline" onClick={downloadSampleCSV}>
                    <Download className="h-4 w-4 mr-2" />
                    Mẫu CSV
                  </Button>
                </div>
                <input ref={fileInputRef} type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
              </div>

              <div className="space-y-2">
                <Label>Hoặc thêm thủ công</Label>
                <div className="space-y-2">
                  <Input id="manual-email" placeholder="Email" />
                  <Input id="manual-name" placeholder="Tên (tùy chọn)" />
                  <Input id="manual-company" placeholder="Công ty (tùy chọn)" />
                  <Button onClick={addManualEmail} className="w-full">
                    Thêm email
                  </Button>
                </div>
              </div>
            </div>

            {recipients.length > 0 && (
              <div className="space-y-2">
                <Label>Danh sách email ({recipients.length})</Label>
                <div className="max-h-32 overflow-y-auto border rounded p-2 space-y-1">
                  {recipients.map((recipient, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span>{recipient.email}</span>
                      <Badge variant="secondary">{recipient.name || "Không có tên"}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Email Template */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">2. Tạo email template</Label>
            <div className="space-y-4">
              <div>
                <Label>Tiêu đề email</Label>
                <Input
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Nhập tiêu đề email..."
                />
              </div>

              <div>
                <Label>Nội dung email (hỗ trợ HTML và placeholder)</Label>
                <Textarea
                  value={template}
                  onChange={(e) => setTemplate(e.target.value)}
                  placeholder="Nhập nội dung email... Sử dụng {{name}}, {{email}}, {{company}} để thay thế tự động"
                  rows={10}
                />
                <div className="text-sm text-muted-foreground mt-1">
                  Placeholder có sẵn: {`{{name}}`}, {`{{email}}`}, {`{{company}}`}
                  <Button
                    variant="link"
                    size="sm"
                    onClick={() => setTemplate(sampleTemplate)}
                    className="p-0 h-auto ml-2"
                  >
                    Sử dụng mẫu
                  </Button>
                </div>
              </div>

              {recipients.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => setShowPreview(!showPreview)}>
                      <Eye className="h-4 w-4 mr-2" />
                      {showPreview ? "Ẩn preview" : "Xem preview"}
                    </Button>
                    {showPreview && recipients.length > 1 && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setPreviewIndex(Math.max(0, previewIndex - 1))}
                          disabled={previewIndex === 0}
                        >
                          ←
                        </Button>
                        <span className="text-sm">
                          {previewIndex + 1} / {recipients.length}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setPreviewIndex(Math.min(recipients.length - 1, previewIndex + 1))}
                          disabled={previewIndex === recipients.length - 1}
                        >
                          →
                        </Button>
                      </div>
                    )}
                  </div>

                  {showPreview && (
                    <div className="border rounded p-4 bg-muted/50">
                      <div className="text-sm font-medium mb-2">Preview cho: {recipients[previewIndex]?.email}</div>
                      <div className="text-sm font-medium mb-1">Tiêu đề:</div>
                      <div className="mb-3 p-2 bg-background rounded border">{subject}</div>
                      <div className="text-sm font-medium mb-1">Nội dung:</div>
                      <div
                        className="p-2 bg-background rounded border"
                        dangerouslySetInnerHTML={{ __html: getPreviewEmail() }}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Send Section */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">3. Gửi email</Label>
            <Button
              onClick={sendBulkEmails}
              disabled={isSending || recipients.length === 0}
              className="w-full"
              size="lg"
            >
              <Send className="h-4 w-4 mr-2" />
              {isSending ? `Đang gửi... (${Math.round(progress)}%)` : `Gửi ${recipients.length} email`}
            </Button>

            {isSending && (
              <div className="space-y-2">
                <Progress value={progress} className="w-full" />
                <div className="text-sm text-center text-muted-foreground">{Math.round(progress)}% hoàn thành</div>
              </div>
            )}
          </div>

          {/* Results */}
          {results.length > 0 && (
            <div className="space-y-4">
              <Label className="text-base font-semibold">Kết quả gửi email</Label>
              <div className="space-y-2">
                <div className="flex gap-4 text-sm">
                  <Badge variant="default" className="bg-green-500">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Thành công: {results.filter((r) => r.status === "success").length}
                  </Badge>
                  <Badge variant="destructive">
                    <XCircle className="h-3 w-3 mr-1" />
                    Thất bại: {results.filter((r) => r.status === "error").length}
                  </Badge>
                </div>
                <div className="max-h-40 overflow-y-auto border rounded p-2 space-y-1">
                  {results.map((result, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span>{result.email}</span>
                      <div className="flex items-center gap-2">
                        {result.status === "success" ? (
                          <Badge variant="default" className="bg-green-500">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Thành công
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="h-3 w-3 mr-1" />
                            Lỗi
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
