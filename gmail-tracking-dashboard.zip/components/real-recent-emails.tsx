"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"

interface GmailEmail {
  id: string
  threadId: string
  sender: string
  subject: string
  date: string
  isRead: boolean
  isSpam: boolean
  snippet: string
}

export function RealRecentEmails() {
  const { data: session } = useSession()
  const [emails, setEmails] = useState<GmailEmail[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (session?.accessToken) {
      fetchEmails()

      // Polling mỗi 60 giây để cập nhật email mới
      const interval = setInterval(() => {
        fetchEmails()
      }, 60000)

      return () => clearInterval(interval)
    }
  }, [session])

  const fetchEmails = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/gmail/recent?limit=10")
      if (response.ok) {
        const data = await response.json()
        setEmails(data)
      }
    } catch (error) {
      console.error("Error fetching emails:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (email: GmailEmail) => {
    if (email.isSpam) return "bg-red-500"
    if (!email.isRead) return "bg-blue-500"
    return "bg-green-500"
  }

  const getStatusText = (email: GmailEmail) => {
    if (email.isSpam) return "Spam"
    if (!email.isRead) return "Chưa đọc"
    return "Đã đọc"
  }

  const extractSenderName = (sender: string) => {
    const match = sender.match(/^([^<]+)/)
    return match ? match[1].trim() : sender
  }

  if (!session) {
    return null
  }

  return (
    <Card className="col-span-3">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Email Gần Đây từ Gmail</CardTitle>
            <CardDescription>
              Danh sách email mới nhất từ hộp thư Gmail của bạn
              {emails.length > 0 && <span className="text-green-600 ml-2">✓ Đã kết nối Gmail</span>}
            </CardDescription>
          </div>
          <Button variant="outline" size="icon" onClick={fetchEmails} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin mr-2" />
            <span>Đang tải email...</span>
          </div>
        ) : emails.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">Không có email nào được tìm thấy</div>
        ) : (
          <div className="space-y-4">
            {emails.map((email) => (
              <div
                key={email.id}
                className="flex items-start space-x-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <Avatar className="h-9 w-9">
                  <AvatarFallback>{extractSenderName(email.sender).charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium leading-none truncate">{extractSenderName(email.sender)}</p>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={email.isSpam ? "destructive" : email.isRead ? "secondary" : "default"}
                        className="text-xs"
                      >
                        {getStatusText(email)}
                      </Badge>
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(email)}`} />
                    </div>
                  </div>
                  <p className="text-sm font-medium truncate">{email.subject || "(Không có tiêu đề)"}</p>
                  <p className="text-xs text-muted-foreground truncate">{email.snippet}</p>
                  <p className="text-xs text-muted-foreground">{email.date}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
