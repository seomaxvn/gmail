"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts"
import { Loader2, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ChartData {
  date: string
  received: number
  sent: number
  spam: number
}

export function EmailChart() {
  const { data: session } = useSession()
  const [chartData, setChartData] = useState<ChartData[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (session?.accessToken) {
      fetchChartData()
    }
  }, [session])

  const fetchChartData = async () => {
    setLoading(true)
    try {
      // Lấy dữ liệu email trong 7 ngày qua
      const today = new Date()
      const chartData: ChartData[] = []

      for (let i = 6; i >= 0; i--) {
        const date = new Date(today)
        date.setDate(date.getDate() - i)

        const formattedDate = `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}`

        // Tạo query cho ngày cụ thể
        const dateQuery = date.toISOString().split("T")[0]

        // Gọi API để lấy số lượng email cho ngày này
        const [receivedRes, sentRes, spamRes] = await Promise.all([
          fetch(`/api/gmail/daily-stats?date=${dateQuery}&type=received`),
          fetch(`/api/gmail/daily-stats?date=${dateQuery}&type=sent`),
          fetch(`/api/gmail/daily-stats?date=${dateQuery}&type=spam`),
        ])

        let received = 0,
          sent = 0,
          spam = 0

        if (receivedRes.ok) {
          const data = await receivedRes.json()
          received = data.count || 0
        }
        if (sentRes.ok) {
          const data = await sentRes.json()
          sent = data.count || 0
        }
        if (spamRes.ok) {
          const data = await spamRes.json()
          spam = data.count || 0
        }

        chartData.push({
          date: formattedDate,
          received,
          sent,
          spam,
        })
      }

      setChartData(chartData)
    } catch (error) {
      console.error("Error fetching chart data:", error)
      // Fallback to demo data if API fails
      setChartData([
        { date: "01/12", received: 0, sent: 0, spam: 0 },
        { date: "02/12", received: 0, sent: 0, spam: 0 },
        { date: "03/12", received: 0, sent: 0, spam: 0 },
        { date: "04/12", received: 0, sent: 0, spam: 0 },
        { date: "05/12", received: 0, sent: 0, spam: 0 },
        { date: "06/12", received: 0, sent: 0, spam: 0 },
        { date: "07/12", received: 0, sent: 0, spam: 0 },
      ])
    } finally {
      setLoading(false)
    }
  }

  if (!session) {
    return null
  }

  return (
    <Card className="col-span-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Thống Kê Email Theo Ngày (Gmail Thật)</CardTitle>
            <CardDescription>Biểu đồ hiển thị số lượng email từ Gmail của bạn trong 7 ngày qua</CardDescription>
          </div>
          <Button variant="outline" size="icon" onClick={fetchChartData} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pl-2">
        {loading ? (
          <div className="flex items-center justify-center h-[350px]">
            <Loader2 className="h-6 w-6 animate-spin mr-2" />
            <span>Đang tải dữ liệu từ Gmail...</span>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value}`}
              />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="received" stroke="#8884d8" strokeWidth={2} name="Email Nhận" />
              <Line type="monotone" dataKey="sent" stroke="#82ca9d" strokeWidth={2} name="Email Gửi" />
              <Line type="monotone" dataKey="spam" stroke="#ff7300" strokeWidth={2} name="Spam" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  )
}
