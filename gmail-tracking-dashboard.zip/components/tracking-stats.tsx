"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Eye, MousePointer, Mail, TrendingUp, Loader2, RefreshCw, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"

interface TrackingStats {
  totalEmails: number
  openedEmails: number
  totalOpens: number
  totalClicks: number
  openRate: number
  clickRate: number
}

interface TrackedEmail {
  id: string
  trackingId: string
  recipient: string
  subject: string
  sentAt: string
  openCount: number
  clickCount: number
  isOpened: boolean
  firstOpenAt?: string
  lastOpenAt?: string
}

export function TrackingStats() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<TrackingStats | null>(null)
  const [emails, setEmails] = useState<TrackedEmail[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Fetch data ngay lập tức
    fetchData()

    // Polling mỗi 5 giây để cập nhật real-time
    const interval = setInterval(() => {
      fetchData()
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      console.log("🔄 Fetching tracking data...")

      const [statsResponse, emailsResponse] = await Promise.all([
        fetch("/api/tracking/stats"),
        fetch("/api/tracking/emails?limit=10"),
      ])

      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData)
        console.log("📊 Stats updated:", statsData)
      } else {
        console.error("❌ Stats API error:", statsResponse.status)
      }

      if (emailsResponse.ok) {
        const emailsData = await emailsResponse.json()
        setEmails(emailsData)
        console.log("📧 Emails updated:", emailsData.length, "emails")
      } else {
        console.error("❌ Emails API error:", emailsResponse.status)
      }
    } catch (error) {
      console.error("Error fetching tracking data:", error)
    } finally {
      setLoading(false)
    }
  }

  const addSampleData = async () => {
    try {
      // Tạo sample tracking data
      const sampleTrackingId = Math.random().toString(36).substring(2, 15) + Date.now().toString(36)

      const response = await fetch("/api/tracking/sample", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          trackingId: sampleTrackingId,
          recipient: "sample@test.com",
          subject: "Sample Email for Testing",
        }),
      })

      if (response.ok) {
        fetchData() // Refresh data
      }
    } catch (error) {
      console.error("Error adding sample data:", error)
    }
  }

  return (
    <div className="space-y-6">
      {/* Thống kê tổng quan */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Email Đã Gửi</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalEmails || 0}</div>
            <p className="text-xs text-muted-foreground">Tổng số email có tracking</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tỷ Lệ Mở</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.openRate.toFixed(1) || 0}%</div>
            <Progress value={stats?.openRate || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tỷ Lệ Click</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.clickRate.toFixed(1) || 0}%</div>
            <Progress value={stats?.clickRate || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tổng Lượt Mở</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalOpens || 0}</div>
            <p className="text-xs text-muted-foreground">{stats?.totalClicks || 0} lượt click</p>
          </CardContent>
        </Card>
      </div>

      {/* Danh sách email tracking */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Email Tracking Chi Tiết</CardTitle>
              <CardDescription>Theo dõi chi tiết từng email đã gửi (cập nhật mỗi 5 giây)</CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={addSampleData}>
                <Plus className="h-4 w-4 mr-2" />
                Thêm Sample
              </Button>
              <Button variant="outline" size="icon" onClick={fetchData} disabled={loading}>
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin mr-2" />
              <span>Đang tải dữ liệu tracking...</span>
            </div>
          ) : emails.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">Chưa có email nào được tracking</p>
              <Button onClick={addSampleData} variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Thêm Sample Data để Test
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {emails.map((email) => (
                <div
                  key={email.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center space-x-2">
                      <p className="font-medium">{email.subject}</p>
                      {email.isOpened ? (
                        <Badge variant="default" className="text-xs">
                          <Eye className="h-3 w-3 mr-1" />
                          Đã mở
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          Chưa mở
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">Đến: {email.recipient}</p>
                    <p className="text-xs text-muted-foreground">
                      Gửi lúc: {new Date(email.sentAt).toLocaleString("vi-VN")}
                    </p>
                    {email.firstOpenAt && (
                      <p className="text-xs text-muted-foreground">
                        Mở lần đầu: {new Date(email.firstOpenAt).toLocaleString("vi-VN")}
                      </p>
                    )}
                  </div>
                  <div className="text-right space-y-1">
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1">
                        <Eye className="h-4 w-4 text-blue-500" />
                        <span>{email.openCount}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MousePointer className="h-4 w-4 text-green-500" />
                        <span>{email.clickCount}</span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">ID: {email.trackingId}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
