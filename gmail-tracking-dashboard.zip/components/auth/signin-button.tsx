"use client"

import { signIn, signOut, useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Mail, LogOut, Info } from "lucide-react"

export function SignInButton() {
  const { data: session, status } = useSession()

  if (status === "loading") {
    return <Button disabled>Đang tải...</Button>
  }

  if (session) {
    return (
      <div className="flex items-center space-x-4">
        <span className="text-sm text-muted-foreground">Đã kết nối: {session.user?.email}</span>
        <Button variant="outline" onClick={() => signOut()}>
          <LogOut className="h-4 w-4 mr-2" />
          Đăng xuất
        </Button>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md mx-auto space-y-4">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center space-x-2">
            <Mail className="h-6 w-6" />
            <span>Kết nối Gmail</span>
          </CardTitle>
          <CardDescription>Đăng nhập để tracking email từ Gmail của bạn</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Lưu ý:</strong> Email của bạn cần được thêm vào danh sách test users trong Google Cloud Console.
            </AlertDescription>
          </Alert>

          <Button onClick={() => signIn("google")} className="w-full" size="lg">
            <Mail className="h-4 w-4 mr-2" />
            Đăng nhập với Google
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Hướng dẫn khắc phục lỗi 403</CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2">
          <p>
            <strong>Nếu gặp lỗi "access_denied":</strong>
          </p>
          <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
            <li>Truy cập Google Cloud Console</li>
            <li>Vào OAuth consent screen → Test users</li>
            <li>Thêm email Gmail của bạn</li>
            <li>Thử đăng nhập lại</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}
