"use client"

import { BarChart3, Mail, Settings, Shield, Users, Calendar, FileText } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"

const menuItems = [
  {
    title: "Dashboard",
    icon: BarChart3,
    url: "#",
    isActive: true,
  },
  {
    title: "Hộp Thư",
    icon: Mail,
    url: "#",
  },
  {
    title: "Lịch",
    icon: Calendar,
    url: "#",
  },
  {
    title: "Báo Cáo",
    icon: FileText,
    url: "#",
  },
  {
    title: "Người Dùng",
    icon: Users,
    url: "#",
  },
  {
    title: "Bảo Mật",
    icon: Shield,
    url: "#",
  },
  {
    title: "Cài Đặt",
    icon: Settings,
    url: "#",
  },
]

export function AppSidebar() {
  return (
    <Sidebar>
      <SidebarHeader className="border-b px-6 py-4">
        <div className="flex items-center space-x-2">
          <Mail className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold">Gmail Tracker</span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu Chính</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={item.isActive}>
                    <a href={item.url} className="flex items-center space-x-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-4">
        <div className="text-xs text-muted-foreground">© 2024 Gmail Tracker Pro</div>
      </SidebarFooter>
    </Sidebar>
  )
}
