import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface Email {
  id: string
  sender: string
  subject: string
  time: string
  status: "read" | "unread" | "spam"
  priority: "high" | "normal" | "low"
}

const recentEmails: Email[] = [
  {
    id: "1",
    sender: "Nguyễn Văn A",
    subject: "Báo cáo doanh thu tháng 12",
    time: "2 phút trước",
    status: "unread",
    priority: "high",
  },
  {
    id: "2",
    sender: "support@company.com",
    subject: "Cập nhật bảo mật hệ thống",
    time: "15 phút trước",
    status: "read",
    priority: "normal",
  },
  {
    id: "3",
    sender: "marketing@shop.vn",
    subject: "Khuyến mãi cuối năm - Giảm 50%",
    time: "1 giờ trước",
    status: "spam",
    priority: "low",
  },
  {
    id: "4",
    sender: "Trần Thị B",
    subject: "Lịch họp tuần tới",
    time: "2 giờ trước",
    status: "read",
    priority: "normal",
  },
  {
    id: "5",
    sender: "noreply@bank.com",
    subject: "Thông báo giao dịch",
    time: "3 giờ trước",
    status: "unread",
    priority: "high",
  },
]

export function RecentEmails() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "unread":
        return "bg-blue-500"
      case "read":
        return "bg-green-500"
      case "spam":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "normal":
        return "secondary"
      case "low":
        return "outline"
      default:
        return "secondary"
    }
  }

  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle>Email Gần Đây</CardTitle>
        <CardDescription>Danh sách email mới nhất trong hộp thư</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentEmails.map((email) => (
            <div
              key={email.id}
              className="flex items-center space-x-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
            >
              <Avatar className="h-9 w-9">
                <AvatarFallback>{email.sender.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium leading-none">{email.sender}</p>
                  <div className="flex items-center space-x-2">
                    <Badge variant={getPriorityColor(email.priority)} className="text-xs">
                      {email.priority === "high" ? "Cao" : email.priority === "normal" ? "Bình thường" : "Thấp"}
                    </Badge>
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(email.status)}`} />
                  </div>
                </div>
                <p className="text-sm text-muted-foreground truncate">{email.subject}</p>
                <p className="text-xs text-muted-foreground">{email.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
