"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, MailOpen, AlertTriangle, Loader2 } from "lucide-react"

interface EmailStats {
  totalEmails: number
  readEmails: number
  unreadEmails: number
  spamEmails: number
}

export function RealStatsOverview() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<EmailStats | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (session?.accessToken) {
      fetchStats()

      // Polling mỗi 30 giây để cập nhật dữ liệu
      const interval = setInterval(() => {
        fetchStats()
      }, 30000)

      return () => clearInterval(interval)
    }
  }, [session])

  const fetchStats = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/gmail/stats")
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error("Error fetching stats:", error)
    } finally {
      setLoading(false)
    }
  }

  if (!session) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">Vui lòng đăng nhập để xem thống kê Gmail</p>
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span className="text-sm">Đang tải từ Gmail...</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (!stats) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">Không thể tải thống kê email</p>
          <button onClick={fetchStats} className="mt-2 text-primary hover:underline">
            Thử lại
          </button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Tổng Email</CardTitle>
          <Mail className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.totalEmails.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">Từ Gmail của bạn</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Đã Đọc</CardTitle>
          <MailOpen className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.readEmails.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            {stats.totalEmails > 0 ? ((stats.readEmails / stats.totalEmails) * 100).toFixed(1) : 0}% tổng số email
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Chưa Đọc</CardTitle>
          <Mail className="h-4 w-4 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-orange-500">{stats.unreadEmails.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            {stats.totalEmails > 0 ? ((stats.unreadEmails / stats.totalEmails) * 100).toFixed(1) : 0}% tổng số email
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Spam</CardTitle>
          <AlertTriangle className="h-4 w-4 text-red-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-500">{stats.spamEmails.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            {stats.totalEmails > 0 ? ((stats.spamEmails / stats.totalEmails) * 100).toFixed(1) : 0}% tổng số email
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
