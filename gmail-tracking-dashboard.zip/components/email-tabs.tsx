"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RealStatsOverview } from "./real-stats-overview"
import { EmailChart } from "./email-chart"
import { RealRecentEmails } from "./real-recent-emails"
import { SentEmailStats } from "./sent-email-stats"
import { SentEmailsList } from "./sent-emails-list"
import { SendEmailForm } from "./send-email-form"
import { TrackingStats } from "./tracking-stats"
import { TrackingUrlTester } from "./tracking-url-tester"
import { GmailDebugPanel } from "./gmail-debug-panel"
import { BulkEmailSender } from "./bulk-email-sender"

export function EmailTabs() {
  const [activeTab, setActiveTab] = useState("inbox")

  return (
    <Tabs defaultValue="inbox" className="w-full" onValueChange={setActiveTab}>
      <TabsList className="grid w-full grid-cols-7">
        <TabsTrigger value="inbox">Hộp Thư Đến</TabsTrigger>
        <TabsTrigger value="sent">Email Đã Gửi</TabsTrigger>
        <TabsTrigger value="compose">Soạn Email</TabsTrigger>
        <TabsTrigger value="bulk">Gửi Hàng Loạt</TabsTrigger>
        <TabsTrigger value="tracking">Tracking Stats</TabsTrigger>
        <TabsTrigger value="urls">URL Config</TabsTrigger>
        <TabsTrigger value="debug">Debug</TabsTrigger>
      </TabsList>

      <TabsContent value="inbox" className="space-y-4 mt-4">
        <RealStatsOverview />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <EmailChart />
          <RealRecentEmails />
        </div>
      </TabsContent>

      <TabsContent value="sent" className="space-y-4 mt-4">
        <SentEmailStats />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <SentEmailsList />
        </div>
      </TabsContent>

      <TabsContent value="compose" className="mt-4">
        <SendEmailForm />
      </TabsContent>

      <TabsContent value="bulk" className="mt-4">
        <BulkEmailSender />
      </TabsContent>

      <TabsContent value="tracking" className="mt-4">
        <TrackingStats />
      </TabsContent>

      <TabsContent value="urls" className="mt-4">
        <TrackingUrlTester />
      </TabsContent>

      <TabsContent value="debug" className="mt-4">
        <GmailDebugPanel />
      </TabsContent>
    </Tabs>
  )
}
