import { google } from "googleapis"
import { TrackingDatabase } from "./database"

export class GmailClient {
  private gmail: any

  constructor(accessToken: string) {
    const auth = new google.auth.OAuth2()
    auth.setCredentials({ access_token: accessToken })

    this.gmail = google.gmail({ version: "v1", auth })
  }

  async getProfile() {
    try {
      const response = await this.gmail.users.getProfile({ userId: "me" })
      return response.data
    } catch (error) {
      console.error("Error getting profile:", error)
      throw error
    }
  }

  async getMessages(query = "", maxResults = 50) {
    try {
      const response = await this.gmail.users.messages.list({
        userId: "me",
        q: query,
        maxResults,
      })
      return response.data
    } catch (error) {
      console.error("Error getting messages:", error)
      throw error
    }
  }

  async getMessage(messageId: string) {
    try {
      const response = await this.gmail.users.messages.get({
        userId: "me",
        id: messageId,
        format: "full",
      })
      return response.data
    } catch (error) {
      console.error("Error getting message:", error)
      throw error
    }
  }

  async getEmailStats() {
    try {
      // Lấy tổng số email
      const allMessages = await this.getMessages("", 1000)
      const totalEmails = allMessages.resultSizeEstimate || 0

      // Lấy email chưa đọc
      const unreadMessages = await this.getMessages("is:unread", 1000)
      const unreadEmails = unreadMessages.resultSizeEstimate || 0

      // Lấy email spam
      const spamMessages = await this.getMessages("in:spam", 1000)
      const spamEmails = spamMessages.resultSizeEstimate || 0

      // Lấy email đã gửi
      const sentMessages = await this.getMessages("in:sent", 1000)
      const sentEmails = sentMessages.resultSizeEstimate || 0

      // Tính email đã đọc
      const readEmails = totalEmails - unreadEmails

      return {
        totalEmails,
        readEmails,
        unreadEmails,
        spamEmails,
        sentEmails,
      }
    } catch (error) {
      console.error("Error getting email stats:", error)
      throw error
    }
  }

  async getRecentEmails(limit = 10) {
    try {
      const messages = await this.getMessages("", limit)

      if (!messages.messages) return []

      const emailDetails = await Promise.all(
        messages.messages.map(async (message: any) => {
          const detail = await this.getMessage(message.id)
          const headers = detail.payload?.headers || []

          const getHeader = (name: string) =>
            headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || ""

          return {
            id: detail.id,
            threadId: detail.threadId,
            sender: getHeader("from"),
            subject: getHeader("subject"),
            date: new Date(Number.parseInt(detail.internalDate)).toLocaleString("vi-VN"),
            isRead: !detail.labelIds?.includes("UNREAD"),
            isSpam: detail.labelIds?.includes("SPAM"),
            snippet: detail.snippet,
          }
        }),
      )

      return emailDetails
    } catch (error) {
      console.error("Error getting recent emails:", error)
      throw error
    }
  }

  // Thêm phương thức để lấy email đã gửi
  async getSentEmails(limit = 10) {
    try {
      const messages = await this.getMessages("in:sent", limit)

      if (!messages.messages) return []

      const emailDetails = await Promise.all(
        messages.messages.map(async (message: any) => {
          const detail = await this.getMessage(message.id)
          const headers = detail.payload?.headers || []

          const getHeader = (name: string) =>
            headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || ""

          return {
            id: detail.id,
            threadId: detail.threadId,
            recipient: getHeader("to"),
            subject: getHeader("subject"),
            date: new Date(Number.parseInt(detail.internalDate)).toLocaleString("vi-VN"),
            snippet: detail.snippet,
            // Thêm thông tin tracking
            hasAttachment:
              detail.payload?.parts?.some((part: any) => part.filename && part.filename.length > 0) || false,
            size: this.calculateEmailSize(detail),
          }
        }),
      )

      return emailDetails
    } catch (error) {
      console.error("Error getting sent emails:", error)
      throw error
    }
  }

  // Thêm phương thức để lấy thống kê email gửi đi theo thời gian
  async getSentEmailStats() {
    try {
      // Lấy email gửi đi trong 7 ngày qua
      const today = new Date()
      const stats = []

      for (let i = 6; i >= 0; i--) {
        const date = new Date(today)
        date.setDate(date.getDate() - i)

        const formattedDate = date.toISOString().split("T")[0]
        const query = `in:sent after:${formattedDate} before:${formattedDate}`

        const response = await this.getMessages(query, 1000)
        const count = response.resultSizeEstimate || 0

        stats.push({
          date: `${date.getDate()}/${date.getMonth() + 1}`,
          count,
        })
      }

      return stats
    } catch (error) {
      console.error("Error getting sent email stats:", error)
      throw error
    }
  }

  // Thêm phương thức mới để lấy thống kê theo ngày:
  async getDailyEmailCount(date: string, type: "received" | "sent" | "spam") {
    try {
      let query = ""

      switch (type) {
        case "received":
          query = `in:inbox after:${date} before:${date}`
          break
        case "sent":
          query = `in:sent after:${date} before:${date}`
          break
        case "spam":
          query = `in:spam after:${date} before:${date}`
          break
        default:
          throw new Error("Invalid type parameter")
      }

      const response = await this.getMessages(query, 1000)
      return response.resultSizeEstimate || 0
    } catch (error) {
      console.error(`Error getting ${type} email count for ${date}:`, error)
      return 0
    }
  }

  // FIXED: Cập nhật phương thức gửi email với tracking
  async sendEmailWithTracking(to: string, subject: string, body: string, enableTracking = true) {
    try {
      console.log("🚀 Starting email send with tracking...")
      console.log("📧 Email details:", { to, subject, enableTracking })

      // Tạo tracking ID duy nhất
      const trackingId = Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
      console.log("🆔 Generated tracking ID:", trackingId)

      let emailContent = body

      if (enableTracking) {
        // Sử dụng domain cố định
        const baseUrl = "https://v0-new-project-ranh0lwla77.vercel.app"

        // Tạo tracking pixel URL
        const trackingPixelUrl = `${baseUrl}/api/track/${trackingId}`
        console.log("🔗 Tracking pixel URL:", trackingPixelUrl)

        // Thêm tracking pixel vào cuối email (ẩn)
        const trackingPixel = `<img src="${trackingPixelUrl}" width="1" height="1" style="display:none;" alt="" />`

        // Xử lý links trong email để thêm click tracking
        emailContent = this.addClickTracking(body, trackingId, baseUrl)

        // Thêm tracking pixel vào cuối email
        emailContent += `\n${trackingPixel}`

        console.log("✅ Added tracking pixel to email")
        console.log("📝 Final email content preview:", emailContent.substring(0, 200) + "...")
      }

      // Tạo email HTML hoàn chỉnh
      const htmlEmail = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
  ${emailContent}
</body>
</html>`

      console.log("📄 Complete HTML email length:", htmlEmail.length)

      // Encode email để gửi qua Gmail API
      const email = [
        'Content-Type: text/html; charset="UTF-8"',
        "MIME-Version: 1.0",
        `To: ${to}`,
        `Subject: ${subject}`,
        "",
        htmlEmail,
      ].join("\n")

      const encodedEmail = Buffer.from(email)
        .toString("base64")
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "")

      console.log("📦 Encoded email length:", encodedEmail.length)

      // Gửi email
      console.log("📤 Sending email via Gmail API...")
      const response = await this.gmail.users.messages.send({
        userId: "me",
        requestBody: {
          raw: encodedEmail,
        },
      })

      console.log("✅ Email sent successfully:", response.data.id)

      // Lưu thông tin tracking vào database TRƯỚC KHI trả về kết quả
      if (enableTracking) {
        console.log("💾 Saving tracking data to database...")
        const trackingData = await TrackingDatabase.createEmailTracking({
          messageId: response.data.id,
          trackingId,
          recipient: to,
          subject,
          sentAt: new Date(),
        })
        console.log("✅ Tracking data saved:", trackingData.id)
      }

      const result = {
        messageId: response.data.id,
        threadId: response.data.threadId,
        trackingId: enableTracking ? trackingId : null,
        trackingUrl: enableTracking ? `https://v0-new-project-ranh0lwla77.vercel.app/api/track/${trackingId}` : null,
      }

      console.log("🎉 Email send completed:", result)
      return result
    } catch (error) {
      console.error("❌ Error sending email with tracking:", error)
      throw error
    }
  }

  // Phương thức để lấy base URL
  private getBaseUrl(): string {
    // Sử dụng domain cố định để tránh vấn đề localhost
    return "https://v0-new-project-ranh0lwla77.vercel.app"
  }

  // Cập nhật phương thức để thêm click tracking vào các links
  private addClickTracking(htmlContent: string, trackingId: string, baseUrl: string): string {
    // Regex để tìm các thẻ <a> với href
    const linkRegex = /<a\s+([^>]*?)href\s*=\s*["']([^"']+)["']([^>]*?)>/gi

    return htmlContent.replace(linkRegex, (match, beforeHref, originalUrl, afterHref) => {
      // Bỏ qua nếu đã là tracking URL
      if (originalUrl.includes("/api/track/click/")) {
        return match
      }

      // Bỏ qua mailto links
      if (originalUrl.startsWith("mailto:")) {
        return match
      }

      // Tạo tracking URL
      const trackingUrl = `${baseUrl}/api/track/click/${trackingId}?url=${encodeURIComponent(originalUrl)}`

      return `<a ${beforeHref}href="${trackingUrl}"${afterHref}>`
    })
  }

  // Phương thức hỗ trợ để tính kích thước email
  private calculateEmailSize(message: any) {
    let size = 0

    // Tính kích thước từ headers
    if (message.payload?.headers) {
      size += JSON.stringify(message.payload.headers).length
    }

    // Tính kích thước từ body
    if (message.payload?.body?.data) {
      size += message.payload.body.data.length
    }

    // Tính kích thước từ các phần đính kèm
    if (message.payload?.parts) {
      message.payload.parts.forEach((part: any) => {
        if (part.body?.data) {
          size += part.body.data.length
        }
      })
    }

    // Chuyển đổi sang KB
    return Math.round(size / 1024)
  }
}
