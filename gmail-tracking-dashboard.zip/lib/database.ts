// Trong thực tế, bạn sẽ sử dụng database thật như PostgreSQL, MongoDB
// Đây là mock database để demo

interface TrackingEvent {
  id: string
  emailId: string
  trackingId: string
  eventType: "open" | "click"
  timestamp: Date
  userAgent?: string
  ipAddress?: string
  location?: string
}

interface EmailTracking {
  id: string
  messageId: string
  trackingId: string
  recipient: string
  subject: string
  sentAt: Date
  openCount: number
  clickCount: number
  firstOpenAt?: Date
  lastOpenAt?: Date
  isOpened: boolean
  events: TrackingEvent[]
}

// Mock database với sample data
const trackingDatabase: EmailTracking[] = [
  {
    id: "sample_1",
    messageId: "msg_sample_1",
    trackingId: "qaq34vsbdsmmb90qo42", // Tracking ID từ test của bạn
    recipient: "test@example.com",
    subject: "Test Email from URL Config",
    sentAt: new Date(Date.now() - 30 * 60 * 1000), // 30 phút trước
    openCount: 1,
    clickCount: 0,
    firstOpenAt: new Date(Date.now() - 25 * 60 * 1000),
    lastOpenAt: new Date(Date.now() - 25 * 60 * 1000),
    isOpened: true,
    events: [],
  },
  {
    id: "sample_2",
    messageId: "msg_sample_2",
    trackingId: "demo_tracking_123",
    recipient: "demo@company.com",
    subject: "Demo Email Campaign",
    sentAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 giờ trước
    openCount: 3,
    clickCount: 1,
    firstOpenAt: new Date(Date.now() - 2 * 60 * 60 * 1000 + 10 * 60 * 1000),
    lastOpenAt: new Date(Date.now() - 30 * 60 * 1000),
    isOpened: true,
    events: [],
  },
]

const eventsDatabase: TrackingEvent[] = []

export class TrackingDatabase {
  static async createEmailTracking(
    data: Omit<EmailTracking, "id" | "openCount" | "clickCount" | "isOpened" | "events">,
  ) {
    const tracking: EmailTracking = {
      ...data,
      id: Math.random().toString(36).substring(2, 15),
      openCount: 0,
      clickCount: 0,
      isOpened: false,
      events: [],
    }

    trackingDatabase.push(tracking)
    console.log("✅ Created email tracking:", {
      id: tracking.id,
      trackingId: tracking.trackingId,
      recipient: tracking.recipient,
      subject: tracking.subject,
    })
    return tracking
  }

  static async recordEvent(trackingId: string, eventType: "open" | "click", metadata?: any) {
    console.log(`🔍 Looking for tracking ID: ${trackingId}`)
    console.log(`📊 Current database has ${trackingDatabase.length} entries`)

    const tracking = trackingDatabase.find((t) => t.trackingId === trackingId)
    if (!tracking) {
      console.log("❌ Tracking not found for ID:", trackingId)
      console.log(
        "📋 Available tracking IDs:",
        trackingDatabase.map((t) => t.trackingId),
      )
      return null
    }

    const event: TrackingEvent = {
      id: Math.random().toString(36).substring(2, 15),
      emailId: tracking.id,
      trackingId,
      eventType,
      timestamp: new Date(),
      userAgent: metadata?.userAgent,
      ipAddress: metadata?.ipAddress,
      location: metadata?.location,
    }

    eventsDatabase.push(event)
    tracking.events.push(event)

    if (eventType === "open") {
      tracking.openCount++
      if (!tracking.firstOpenAt) {
        tracking.firstOpenAt = event.timestamp
      }
      tracking.lastOpenAt = event.timestamp
      tracking.isOpened = true
    } else if (eventType === "click") {
      tracking.clickCount++
    }

    console.log(`✅ Recorded ${eventType} event for tracking:`, {
      trackingId,
      openCount: tracking.openCount,
      clickCount: tracking.clickCount,
    })
    return event
  }

  static async getTrackingByTrackingId(trackingId: string) {
    return trackingDatabase.find((t) => t.trackingId === trackingId)
  }

  static async getTrackingStats() {
    const totalEmails = trackingDatabase.length
    const openedEmails = trackingDatabase.filter((t) => t.isOpened).length
    const totalOpens = trackingDatabase.reduce((sum, t) => sum + t.openCount, 0)
    const totalClicks = trackingDatabase.reduce((sum, t) => sum + t.clickCount, 0)

    const stats = {
      totalEmails,
      openedEmails,
      totalOpens,
      totalClicks,
      openRate: totalEmails > 0 ? (openedEmails / totalEmails) * 100 : 0,
      clickRate: totalEmails > 0 ? (totalClicks / totalEmails) * 100 : 0,
    }

    console.log("📊 Current tracking stats:", stats)
    return stats
  }

  static async getRecentTrackings(limit = 10) {
    const recent = trackingDatabase.sort((a, b) => b.sentAt.getTime() - a.sentAt.getTime()).slice(0, limit)
    console.log(`📧 Returning ${recent.length} recent trackings`)
    return recent
  }

  // Debug method để xem tất cả tracking data
  static async getAllTrackings() {
    console.log("🗂️ All tracking data:", trackingDatabase)
    return trackingDatabase
  }

  // Debug methods
  static async debugTrackingData() {
    console.log("🗂️ === TRACKING DATABASE DEBUG ===")
    console.log(`📊 Total trackings: ${trackingDatabase.length}`)
    console.log(`📊 Total events: ${eventsDatabase.length}`)

    trackingDatabase.forEach((tracking, index) => {
      console.log(`📧 [${index + 1}] ${tracking.trackingId} - ${tracking.subject}`)
      console.log(`   👤 To: ${tracking.recipient}`)
      console.log(`   📅 Sent: ${tracking.sentAt.toLocaleString()}`)
      console.log(`   👁️ Opens: ${tracking.openCount}, 🖱️ Clicks: ${tracking.clickCount}`)
      console.log(`   📋 Events: ${tracking.events.length}`)
    })

    return {
      totalTrackings: trackingDatabase.length,
      totalEvents: eventsDatabase.length,
      trackings: trackingDatabase,
      events: eventsDatabase,
    }
  }

  static async resetAllData() {
    trackingDatabase.length = 0
    eventsDatabase.length = 0
    console.log("🗑️ All tracking data reset")
  }
}
