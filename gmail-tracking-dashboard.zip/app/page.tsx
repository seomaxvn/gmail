"use client"

import { SessionProvider } from "next-auth/react"
import Dashboard from "../dashboard"

export default function Page() {
  return (
    <SessionProvider>
      <Dashboard />
    </SessionProvider>
  )
}
