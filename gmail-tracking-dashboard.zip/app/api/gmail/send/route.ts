import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { GmailClient } from "@/lib/gmail"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.accessToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { to, subject, body } = await request.json()

    if (!to || !subject || !body) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const gmailClient = new GmailClient(session.accessToken)
    const result = await gmailClient.sendEmailWithTracking(to, subject, body)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Gmail send email error:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}
