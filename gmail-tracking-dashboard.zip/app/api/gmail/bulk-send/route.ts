import type { NextRequest } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { GmailClient } from "@/lib/gmail"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.accessToken) {
      return new Response("Unauthorized", { status: 401 })
    }

    const { recipients, subject, template } = await request.json()

    if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
      return new Response("Invalid recipients", { status: 400 })
    }

    if (!subject || !template) {
      return new Response("Subject and template are required", { status: 400 })
    }

    console.log(`🚀 Starting bulk email send to ${recipients.length} recipients`)

    const gmail = new GmailClient(session.accessToken)

    // Create a readable stream for real-time progress
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        let successCount = 0
        let errorCount = 0

        for (let i = 0; i < recipients.length; i++) {
          const recipient = recipients[i]

          try {
            console.log(`📧 Sending email ${i + 1}/${recipients.length} to ${recipient.email}`)

            // Replace template placeholders
            let emailContent = template
            Object.keys(recipient).forEach((key) => {
              const value = recipient[key] || ""
              emailContent = emailContent.replace(new RegExp(`{{${key}}}`, "g"), value)
            })

            // Send email with proper UTF-8 encoding
            const result = await gmail.sendEmailWithTracking(
              recipient.email,
              subject,
              emailContent,
              true, // Enable tracking
            )

            successCount++

            // Send success result
            const resultData = {
              type: "result",
              result: {
                email: recipient.email,
                status: "success",
                message: "Email sent successfully",
                trackingId: result.trackingId,
              },
            }
            controller.enqueue(encoder.encode(JSON.stringify(resultData) + "\n"))

            console.log(`✅ Email sent successfully to ${recipient.email}, tracking ID: ${result.trackingId}`)
          } catch (error) {
            errorCount++
            console.error(`❌ Failed to send email to ${recipient.email}:`, error)

            // Send error result
            const resultData = {
              type: "result",
              result: {
                email: recipient.email,
                status: "error",
                message: error instanceof Error ? error.message : "Unknown error",
              },
            }
            controller.enqueue(encoder.encode(JSON.stringify(resultData) + "\n"))
          }

          // Send progress update
          const progress = ((i + 1) / recipients.length) * 100
          const progressData = {
            type: "progress",
            progress: progress,
            current: i + 1,
            total: recipients.length,
            success: successCount,
            error: errorCount,
          }
          controller.enqueue(encoder.encode(JSON.stringify(progressData) + "\n"))

          // Add delay to avoid rate limiting (1 second between emails)
          if (i < recipients.length - 1) {
            await new Promise((resolve) => setTimeout(resolve, 1000))
          }
        }

        console.log(`🎉 Bulk email send completed. Success: ${successCount}, Errors: ${errorCount}`)
        controller.close()
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
      },
    })
  } catch (error) {
    console.error("Error in bulk email send:", error)
    return new Response("Internal Server Error", { status: 500 })
  }
}
