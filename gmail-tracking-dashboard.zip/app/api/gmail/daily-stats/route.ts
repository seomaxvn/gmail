import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { GmailClient } from "@/lib/gmail"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.accessToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const date = searchParams.get("date") // Format: YYYY-MM-DD
    const type = searchParams.get("type") // received, sent, spam

    if (!date || !type) {
      return NextResponse.json({ error: "Missing date or type parameter" }, { status: 400 })
    }

    const gmailClient = new GmailClient(session.accessToken)
    const count = await gmailClient.getDailyEmailCount(date, type)

    return NextResponse.json({ count, date, type })
  } catch (error) {
    console.error("Gmail daily stats error:", error)
    return NextResponse.json({ error: "Failed to fetch daily stats" }, { status: 500 })
  }
}
