import { type NextRequest, NextResponse } from "next/server"
import { TrackingDatabase } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { trackingId: string } }) {
  const trackingId = params.trackingId
  const { searchParams } = new URL(request.url)
  const originalUrl = searchParams.get("url")

  console.log("🔗 Click tracking request received:")
  console.log("📍 Tracking ID:", trackingId)
  console.log("🌐 Original URL:", originalUrl)
  console.log("🔍 Full request URL:", request.url)

  if (!originalUrl) {
    console.log("❌ Missing URL parameter")
    return NextResponse.json({ error: "Missing URL parameter" }, { status: 400 })
  }

  try {
    // Lấy thông tin request
    const userAgent = request.headers.get("user-agent") || ""
    const forwardedFor = request.headers.get("x-forwarded-for")
    const realIp = request.headers.get("x-real-ip")
    const ipAddress = forwardedFor?.split(",")[0] || realIp || "unknown"

    console.log("📊 Request metadata:")
    console.log("🖥️ User Agent:", userAgent.substring(0, 100) + "...")
    console.log("🌍 IP Address:", ipAddress)

    // Ghi lại sự kiện click
    const event = await TrackingDatabase.recordEvent(trackingId, "click", {
      userAgent,
      ipAddress,
      originalUrl,
      timestamp: new Date(),
    })

    if (event) {
      console.log("✅ Click event recorded successfully:", event.id)
    } else {
      console.log("⚠️ Click event not recorded - tracking ID not found")
    }

    console.log(`🔗 Redirecting to: ${originalUrl}`)

    // Redirect đến URL gốc
    return NextResponse.redirect(originalUrl)
  } catch (error) {
    console.error("❌ Click tracking error:", error)

    // Vẫn redirect ngay cả khi có lỗi để không làm gián đoạn user experience
    console.log(`🔄 Fallback redirect to: ${originalUrl}`)
    return NextResponse.redirect(originalUrl)
  }
}
