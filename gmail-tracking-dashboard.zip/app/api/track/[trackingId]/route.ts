import { type NextRequest, NextResponse } from "next/server"
import { TrackingDatabase } from "@/lib/database"

// Tạo 1x1 pixel transparent PNG
const TRACKING_PIXEL = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==",
  "base64",
)

export async function GET(request: NextRequest, { params }: { params: { trackingId: string } }) {
  const trackingId = params.trackingId

  try {
    // Lấy thông tin metadata từ request
    const userAgent = request.headers.get("user-agent") || ""
    const forwardedFor = request.headers.get("x-forwarded-for")
    const realIp = request.headers.get("x-real-ip")
    const ipAddress = forwardedFor?.split(",")[0] || realIp || "unknown"

    // Ghi lại sự kiện mở email
    await TrackingDatabase.recordEvent(trackingId, "open", {
      userAgent,
      ipAddress,
      timestamp: new Date(),
    })

    console.log(`📧 Email opened - Tracking ID: ${trackingId}`)

    // Trả về tracking pixel
    return new NextResponse(TRACKING_PIXEL, {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
        "Content-Length": TRACKING_PIXEL.length.toString(),
      },
    })
  } catch (error) {
    console.error("Tracking error:", error)

    // Vẫn trả về pixel ngay cả khi có lỗi
    return new NextResponse(TRACKING_PIXEL, {
      status: 200,
      headers: {
        "Content-Type": "image/png",
      },
    })
  }
}
