import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const baseUrl = getBaseUrl(request)

    const config = {
      baseUrl,
      trackingPixelEndpoint: `${baseUrl}/api/track/{trackingId}`,
      clickTrackingEndpoint: `${baseUrl}/api/track/click/{trackingId}`,
      environment: process.env.NODE_ENV,
      vercelUrl: process.env.VERCEL_URL,
      nextAuthUrl: process.env.NEXTAUTH_URL,
    }

    return NextResponse.json(config)
  } catch (error) {
    console.error("Config error:", error)
    return NextResponse.json({ error: "Failed to get configuration" }, { status: 500 })
  }
}

function getBaseUrl(request: NextRequest): string {
  // Ưu tiên sử dụng NEXTAUTH_URL từ environment
  if (process.env.NEXTAUTH_URL) {
    return process.env.NEXTAUTH_URL
  }

  // Lấy từ request headers
  const host = request.headers.get("host")
  const protocol = request.headers.get("x-forwarded-proto") || "https"

  if (host) {
    return `${protocol}://${host}`
  }

  // Fallback cho development
  if (process.env.NODE_ENV === "development") {
    return "http://localhost:3000"
  }

  // Fallback cho production (Vercel)
  if (process.env.VERCEL_URL) {
    return `https://${process.env.VERCEL_URL}`
  }

  // Default fallback
  return "https://v0-new-project-ranh0lwla77.vercel.app"
}
