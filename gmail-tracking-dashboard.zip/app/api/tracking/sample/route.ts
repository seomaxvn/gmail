import { type NextRequest, NextResponse } from "next/server"
import { TrackingDatabase } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { trackingId, recipient, subject } = body

    // Tạo sample tracking data
    const sampleTrackingId = trackingId || Math.random().toString(36).substring(2, 15) + Date.now().toString(36)

    await TrackingDatabase.createEmailTracking({
      messageId: `sample_${Date.now()}`,
      trackingId: sampleTrackingId,
      recipient: recipient || "sample@test.com",
      subject: subject || "Sample Email for Testing",
      sentAt: new Date(),
    })

    return NextResponse.json({
      success: true,
      trackingId: sampleTrackingId,
      message: "Sample tracking data created",
    })
  } catch (error) {
    console.error("Error creating sample data:", error)
    return NextResponse.json({ error: "Failed to create sample data" }, { status: 500 })
  }
}
