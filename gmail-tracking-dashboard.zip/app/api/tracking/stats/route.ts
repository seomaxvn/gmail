import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { TrackingDatabase } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.accessToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const stats = await TrackingDatabase.getTrackingStats()
    return NextResponse.json(stats)
  } catch (error) {
    console.error("Tracking stats error:", error)
    return NextResponse.json({ error: "Failed to fetch tracking stats" }, { status: 500 })
  }
}
