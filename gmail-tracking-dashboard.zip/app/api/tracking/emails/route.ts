import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { TrackingDatabase } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.accessToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    const emails = await TrackingDatabase.getRecentTrackings(limit)
    return NextResponse.json(emails)
  } catch (error) {
    console.error("Tracking emails error:", error)
    return NextResponse.json({ error: "Failed to fetch tracking emails" }, { status: 500 })
  }
}
