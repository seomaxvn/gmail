"use client"

import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, ArrowLeft } from "lucide-react"
import Link from "next/link"

const errorMessages = {
  Configuration: "Có lỗi cấu hình OAuth. Vui lòng kiểm tra Google Cloud Console.",
  AccessDenied: "Truy cập bị từ chối. Vui lòng kiểm tra quyền ứng dụng.",
  Verification: "Email của bạn chưa được thêm vào danh sách test users.",
  Default: "Có lỗi xảy ra trong quá trình đăng nhập.",
}

export default function AuthError() {
  const searchParams = useSearchParams()
  const error = searchParams.get("error")

  const getErrorMessage = (error: string | null) => {
    switch (error) {
      case "Configuration":
        return errorMessages.Configuration
      case "AccessDenied":
        return errorMessages.AccessDenied
      case "Verification":
        return errorMessages.Verification
      default:
        return errorMessages.Default
    }
  }

  const getErrorSolution = (error: string | null) => {
    switch (error) {
      case "AccessDenied":
        return (
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>
              <strong>Cách khắc phục:</strong>
            </p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Truy cập Google Cloud Console</li>
              <li>Vào OAuth consent screen → Test users</li>
              <li>Thêm email Gmail của bạn vào danh sách</li>
              <li>Thử đăng nhập lại</li>
            </ol>
          </div>
        )
      default:
        return <p className="text-sm text-muted-foreground">Vui lòng liên hệ admin hoặc thử lại sau.</p>
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
            <AlertTriangle className="h-6 w-6 text-red-600" />
          </div>
          <CardTitle className="text-xl">Lỗi Đăng Nhập</CardTitle>
          <CardDescription>{getErrorMessage(error)}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {getErrorSolution(error)}

          <div className="flex flex-col space-y-2">
            <Button asChild>
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Quay về trang chủ
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/api/auth/signin">Thử đăng nhập lại</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
